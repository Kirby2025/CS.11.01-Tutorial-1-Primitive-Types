public class Templateclass {
    public static void main(String[] args) {
        int myInt = 10;
        int myInt2= 4;
        double myDouble = 2.5;
        char myChar = 'A';
        System.out.println(myInt/myDouble);
        System.out.println(myInt/myInt2);
        int myInt3 =  (int)myDouble;
        System.out.println(12.0 /0);
        double myDouble2 = 4.6 ;
        double myDouble3 = 4.4;
        double myDouble4 = 4.5;
        char myChar2 = 'd';
        myInt = 66;
        myDouble2 = myDouble2 +0.5;
        int myDouble5 = (int)myDouble2;
        System.out.println(myDouble5);
        myDouble3 = myDouble3 +0.5;
        int myDouble6 = (int)myDouble3;
        System.out.println(myDouble6);
        myDouble4 = myDouble4 +0.5;
        int myDouble7 = (int)myDouble4;
        System.out.println(myDouble7);
        int myCharint = (int)myChar2;
        System.out.println(myCharint);
        char myIntchar = (char) myInt;
        System.out.println("here" + ++myInt);

    }
}